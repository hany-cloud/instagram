import { createContext } from 'react';

const LoggedInUserContext = createContext(null);
export default LoggedInUserContext;
